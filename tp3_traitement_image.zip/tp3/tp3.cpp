////********************************************************************************************////
////             TP3 : Chaîne complète de traitement d'image                     	            ////
////                                                                                            ////
////																							////
////             Auteurs: MILORME Pierre Rubens, MAGLOIRE Daniel Medou, MALE                    ////
////                                           													////
////																							////
////             Compilation: make
////             Execution : ./tp3 															 	////
////																							////
////
////********************************************************************************************////


#include <stdio.h>
#include <stdlib.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

int main(int argc, char** argv) {

    string nomImage; //Nom de l'image a fournir
    cout << "--------------------------------------------------------------------------";
    cout << "\nBienvenue dans notre programme de chaine complete de traitements d'images.\nEntrez le nom ou le chemin d'acces de l'image"<<endl;
    cout << "--------------------------------------------------------------------------\nNom de l'Image :\t";
    cin >> nomImage;


	Mat image_initiale = imread(nomImage);
	if (!image_initiale.data) {
		cout << "L'image fournie n'est pas valide\n" << endl;
		return -1;
	}


	Mat image1; // declaration d'une variable de type Mat pour stockee l'image qu'on va convertir en niveaus de gris
    cvtColor(image_initiale, image1, COLOR_RGB2GRAY);	//Conversion de l'image couleur en image en niveaux de gris pour appliquer la segmentation dessus

    //conversion de l'image en niveaux de gris en image binaire avec l'algorithme de OTSU qui permet de determiner automatiquement
    //la valeur du seuil sur la base de l'histogramme et les regions modales constituant cet histogramme.
    //Ici nous obtenons une image binaire inverse, c'est-a-dire que les pixels ayant leur valeur en-dessous du seul calcule prendront la valeur
    //255 et les pixels ayant una valeur superieure seront mis a 0.
    //La binarisation est le type de segmentation la plus simple
	threshold(image1, image1, 0, 255, CV_THRESH_BINARY_INV | CV_THRESH_OTSU);//Application de l'algorithme de OTSU pour la segmentation


	//Ci-dessous la phase de traitement apres la segmentation

	//Définition des éléments structurants
	Mat element = getStructuringElement(MORPH_RECT, Size(13, 13));
	Mat element1 = getStructuringElement(MORPH_RECT, Size(7, 7));
	Mat image2;

	//Fermeture des contours
    dilate(image1, image2, element);//dilatation
	erode(image2, image2, element1);//erosion

	// Déclaration d'un vecteur pour contenir les contours des régions détectées
	vector<vector<Point> > contours;

	//Recherche des contours des régions détectées
	findContours(image2, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);

	// Etiquetage des régions
	Mat markers = Mat::zeros(image2.size(), CV_32SC1);
	for (size_t i = 0; i < contours.size(); i++)
		drawContours(markers, contours, static_cast<int>(i),
				Scalar::all(static_cast<int>(i) + 1), -1);

	// Génération aléatoire de couleurs
	vector<Vec3b> colors;
	for (size_t i = 0; i < contours.size(); i++) {
		int blue = theRNG().uniform(0, 255);
		int green = theRNG().uniform(0, 255);
		int red = theRNG().uniform(0, 255);
		colors.push_back(Vec3b((uchar) blue, (uchar) green, (uchar) red));
	}

	// Coloration des régions avec des couleurs différentes
	Mat image3 = Mat::zeros(markers.size(), CV_8UC3);
	for (int i = 0; i < markers.rows; i++) {
		for (int j = 0; j < markers.cols; j++) {
			int index = markers.at<int>(i, j);
			if (index > 0 && index <= static_cast<int>(contours.size()))
				image3.at<Vec3b>(i, j) = colors[index - 1];
			else
				image3.at<Vec3b>(i, j) = Vec3b(0, 0, 0);
		}
	}

	// Et logique entre l'image entrée et le masque obtenu après post-segmentation
	Mat image4;
	image_initiale.copyTo(image4, image3);

	//-----FIN de la phase de post-Segmentation-----

	//Présentation des résultats
	imshow("Image Initiale", image_initiale);
	imshow("Image Segmentee avec OTSU", image1);
	if (!imwrite("image_segmentation_otsu.png", image1))
		cout << "Echec de l'enregistrement" << endl;
	imshow("Image apres segmentation", image3);
	if (!imwrite("image apres segmentation.png", image3))
		cout << "Echec de l'enregistrement" << endl;
	imshow("image_segmentee", image4);
	if (!imwrite("image_segmentee.png", image4))
		cout << "Echec de l'enregistrement" << endl;

	waitKey(0);
	return 0;
}
