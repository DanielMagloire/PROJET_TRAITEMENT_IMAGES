#include <stdio.h>
#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>


using namespace cv;
using namespace std;

// Fonction pour redimensionner l image entree

Mat ResizeImage (Mat ImgInput)// Fonction de redimensionnement de l'image d'entree
{

	    Mat padded;     //image redimensionnee  a renvoyer en sortie

	    // taille optimale de l image redimensionnee
	    int m = getOptimalDFTSize( ImgInput.rows );
	    int n = getOptimalDFTSize( ImgInput.cols );

	    //Valeur de bourrage dans l'image redimensionnee ajoutée
	    copyMakeBorder(ImgInput, padded, 0, m - ImgInput.rows, 0, n - ImgInput.cols, BORDER_CONSTANT, Scalar::all(0));
	    return padded;

}

Mat FourierTransform (Mat ImgRedimensionnee)
//Mat TransformeFourier (Mat ImgRedimensionnee)
{


	    // Creation de deux Conteneurs avec valeurs flottantes pour les parties reelles et imaginaires de la transformee de fourier
	    Mat Conteneurs[] = {Mat_<float>(ImgRedimensionnee), Mat::zeros(ImgRedimensionnee.size(), CV_32F)};

	    //Concatenation des deux conteneurs
	    Mat ImgTransformeFourier;
	    merge(Conteneurs, 2, ImgTransformeFourier);

	    //Transformee de fourier
	    dft(ImgTransformeFourier, ImgTransformeFourier);

	    return ImgTransformeFourier;
}

Mat ComputeNorme (Mat ImgTransformeFourier){


	    vector<Mat> Conteneurs;
	
	    // séparation des parties réelles et imaginaires
	    split(ImgTransformeFourier, Conteneurs);

	    // Calcul de la norme de la transformee de fourier
	    magnitude(Conteneurs[0], Conteneurs[1], Conteneurs[0]);
	    Mat ImgNormeFourier = Conteneurs[0];

	    // Passage à l'echelle logarithmique
	    ImgNormeFourier += Scalar::all(1);
	    log(ImgNormeFourier, ImgNormeFourier);


	    // recadrage du spectre
	    ImgNormeFourier = ImgNormeFourier(Rect(0, 0, ImgNormeFourier.cols & -2, ImgNormeFourier.rows & -2));

	    return ImgNormeFourier;
}

Mat FramesChange (Mat ImgNormeFourier){

	    int cx = ImgNormeFourier.cols/2;
	    int cy = ImgNormeFourier.rows/2;

	    Mat frame0(ImgNormeFourier, Rect(0, 0, cx, cy));   // Cadrant en haut à gauche
	    Mat frame1(ImgNormeFourier, Rect(cx, 0, cx, cy));  // Cadrant en haut à droite
	    Mat frame2(ImgNormeFourier, Rect(0, cy, cx, cy));  // Cadrant en bas à gauche
	    Mat frame3(ImgNormeFourier, Rect(cx, cy, cx, cy)); // Cadrant en bas à droite

	    Mat tmp;                           // tampon pour l echange des cadrants

	    //Echange entre le Cadrant en haut à gauche et le Cadrant en bas à droite
	    frame0.copyTo(tmp);
	    frame3.copyTo(frame0);
	    tmp.copyTo(frame3);

	    //Echange entre le Cadrant en haut à droite et le Cadrant en bas à gauche
	    frame1.copyTo(tmp);
	    frame2.copyTo(frame1);
	    tmp.copyTo(frame2);

	    normalize(ImgNormeFourier, ImgNormeFourier, 0, 1, CV_MINMAX);

	    Mat Sortie;

	    ImgNormeFourier.convertTo(Sortie, CV_8UC1,255);

	    return Sortie;

}

Mat TansformeFourierInverse (Mat ImgTransformeFourier, int nblignes, int nbcolones){
	Mat ImgRestauree;
	Mat ImgFourierInverse;
	vector<Mat> Conteneurs;

	//Transformee inverse de fourier
	dft( ImgTransformeFourier,ImgFourierInverse,DFT_INVERSE + DFT_SCALE);

	split(ImgFourierInverse,Conteneurs);

	ImgRestauree = Conteneurs[0];

	//Recadrage de l image
	ImgRestauree = ImgRestauree(Rect(0, 0, ImgRestauree.cols & -2, ImgRestauree.rows & -2));

	//Conversion en image à niveaux de gris
	ImgRestauree.convertTo(ImgRestauree, CV_8UC1);
	Mat Out (ImgRestauree, Rect(0,0, nbcolones, nblignes));

	return Out;
}




int main(int argc, char ** argv)
{
   if(argc!= 2 ){
		cout << "Veuillez entrer le systaxe suivante:";
		cout << " ./TransformeFourier nom_image"<<endl;
	}
	else
	{
		cout << "Voici le spectre de l'image entrée et l'image issue de la transformee inverse du spectre"<<endl;

		const char* NomImage = argv[1];
		
		// Ouverture de l'image en nuance de gris
		Mat ImgInput = imread(NomImage, CV_LOAD_IMAGE_GRAYSCALE);

		if(!ImgInput.data){
			cout << "Veuillez entrer le nom d'une image existante"<<endl;
			return -1;
		}
		else{

			 // Calcul de la transformé de fourier de l'image

			 Mat TransformeFourierImg = FourierTransform(ResizeImage(ImgInput));

			 Mat SpectreImg = FramesChange(ComputeNorme(TransformeFourierImg));

			 Mat ImgRestauree = TansformeFourierInverse(TransformeFourierImg,ImgInput.rows, ImgInput.cols);

			 imshow("Image Entree", ImgInput);

			 imshow("Spectre de Fourier de l'image entrée", SpectreImg);

			 imshow("Transformée inverse du spectre", ImgRestauree);

			 // Enregistrement de l'image originale
			 if(!imwrite("Image_Entree.png", ImgInput))
			     cout<<"Erreur lors de l'enregistrement"<<endl;

			// Enregistrement de l'image du spectre
			 if(!imwrite("Spectre.png", SpectreImg))
			     cout<<"Erreur lors de l'enregistrement"<<endl;

			// Enregistrement de l'image de la transformée de fourier
			 if(!imwrite("Image_Transformee-Inverse.png", ImgRestauree))
			     cout<<"Erreur lors de l'enregistrement"<<endl;

		}
	}
	waitKey();
	return 0;
}
