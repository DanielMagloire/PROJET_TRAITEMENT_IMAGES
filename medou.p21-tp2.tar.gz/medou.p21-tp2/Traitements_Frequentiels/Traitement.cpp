#include "Traitement.h"
#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

using namespace cv;
using namespace std;

// Fonction pour redimensionner l image entree



Mat ResizeImg (Mat ImgEntree){

	    Mat padded;     //image redimensionnee  a renvoyer en sortie

	    // taille optimale de l image redimensionnee
	    int m = getOptimalDFTSize( ImgEntree.rows );
	    int n = getOptimalDFTSize( ImgEntree.cols );

	    //Ajout de valeur de bourrage dans l'image redimensionnee
	    copyMakeBorder(ImgEntree, padded, 0, m - ImgEntree.rows, 0, n - ImgEntree.cols, BORDER_CONSTANT, Scalar::all(0));
	    return padded;

}

Mat TransformeeFourier (Mat ImgRedimensionnee){


	    // Creation de deux Conteneurs avec valeurs flottantes pour les parties reelles et imaginaires de la transformee de fourier
	    Mat Conteneurs[] = {Mat_<float>(ImgRedimensionnee), Mat::zeros(ImgRedimensionnee.size(), CV_32F)};

	    //Concatenation des deux conteneurs
	    Mat ImgTransformeFourier;
	    merge(Conteneurs, 2, ImgTransformeFourier);

	    //Transformee de fourier
	    dft(ImgTransformeFourier, ImgTransformeFourier);

	    return ImgTransformeFourier;
}

Mat ComputeNorme (Mat ImgTransformeFourier){


	    vector<Mat> Conteneurs;
	    // separation des parties reelles et imaginaires
	    split(ImgTransformeFourier, Conteneurs);

	    // Calcul de norme de la transformee de fourier
	    magnitude(Conteneurs[0], Conteneurs[1], Conteneurs[0]);
	    Mat ImgNormeFourier = Conteneurs[0];

	    // Passage a l echelle logarithmique
	    ImgNormeFourier += Scalar::all(1);
	    log(ImgNormeFourier, ImgNormeFourier);


	    // recadrage du spectre
	    ImgNormeFourier = ImgNormeFourier(Rect(0, 0, ImgNormeFourier.cols & -2, ImgNormeFourier.rows & -2));
	    normalize(ImgNormeFourier, ImgNormeFourier, 0, 1, CV_MINMAX);
	    Mat Sortie;
	    ImgNormeFourier.convertTo(Sortie, CV_8UC1,255);

	    return Sortie;
}

Mat FramesChange (Mat ImgNormeFourier){

	    int cx = ImgNormeFourier.cols/2;
	    int cy = ImgNormeFourier.rows/2;

	    Mat frame0(ImgNormeFourier, Rect(0, 0, cx, cy));   // Cadrant en haut à gauche
	    Mat frame1(ImgNormeFourier, Rect(cx, 0, cx, cy));  // Cadrant en haut à droite
	    Mat frame2(ImgNormeFourier, Rect(0, cy, cx, cy));  // Cadrant en bas à gauche
	    Mat frame3(ImgNormeFourier, Rect(cx, cy, cx, cy)); // Cadrant en bas à droite

	    Mat tmp;                           // tampon pour l echange des cadrants

	    //Echange entre le Cadrant en haut à gauche et le Cadrant en bas à droite
	    frame0.copyTo(tmp);
	    frame3.copyTo(frame0);
	    tmp.copyTo(frame3);

	    //Echange entre le Cadrant en haut à droite et le Cadrant en bas à gauche
	    frame1.copyTo(tmp);
	    frame2.copyTo(frame1);
	    tmp.copyTo(frame2);

	    return ImgNormeFourier;

}

Mat TransformeFourierInverse (Mat ImgTransformeFourier, int nbrelignes, int nbrecolones){
	Mat ImgRestauree;
	Mat ImgTransformeFourierInverse;
	vector<Mat> Conteneurs;

	//Transformee inverse de fourier
	dft( ImgTransformeFourier,ImgTransformeFourierInverse,DFT_INVERSE + DFT_SCALE);

	split(ImgTransformeFourierInverse,Conteneurs);

	ImgRestauree = Conteneurs[0];

	//Recadrage de l image
	ImgRestauree = ImgRestauree(Rect(0, 0, ImgRestauree.cols & -2, ImgRestauree.rows & -2));

	//Conversion en image à niveaux de gris
	ImgRestauree.convertTo(ImgRestauree, CV_8UC1);
	Mat Sortie (ImgRestauree, Rect(0,0, nbrecolones, nbrelignes));

	return Sortie;
}

Mat FiltrePasseBas (Mat ImgTransformeFourier, float frequencecoupure ){
	    Mat ImgFiltrePasseBas;
	    vector<Mat> Conteneurs;
	    float cx = ImgTransformeFourier.cols / (float) 2;
		float cy = ImgTransformeFourier.rows / (float) 2;
		// Determination du rayon du cercle
		int rayon = (int) (min(float(cx), float(cy)))*frequencecoupure;

		split(ImgTransformeFourier,Conteneurs);

		// Mise à jour des valeurs à l'extérieur du cercle
		for(int k = 0; k < (int) Conteneurs.size(); k++){
			FramesChange(Conteneurs[k]);
			for(int i = 0; i < Conteneurs[k].rows; i++)
				for(int j = 0; j < Conteneurs[k].cols; j++)
				{
					if(pow((j - cx),2) + pow((i - cy),2) > pow(rayon,2))
						Conteneurs[k].at<float>(i, j) = 0;
				}
		}
		merge(Conteneurs,ImgFiltrePasseBas);


		return ImgFiltrePasseBas;

}

Mat FiltrePasseHaut (Mat ImgTransformeFourier, float frequencecoupure ){
	    Mat ImgFiltrePasseHaut;
	    vector<Mat> Conteneurs;
	   float cx = ImgTransformeFourier.cols / (float) 2;
		float cy = ImgTransformeFourier.rows / (float) 2;
		// Determination du rayon du cercle
		int rayon = (int) (min(float(cx), float(cy)))*frequencecoupure;

		split(ImgTransformeFourier,Conteneurs);
		// Mise à jour des valeurs à l'interieur du cercle
		for(int k = 0; k < (int) Conteneurs.size(); k++){
			FramesChange(Conteneurs[k]);
			for(int i = 0; i < Conteneurs[k].rows; i++)
				for(int j = 0; j < Conteneurs[k].cols; j++)
				{
					if(pow((j - cx),2) + pow((i - cy),2) < pow(rayon,2))
						Conteneurs[k].at<float>(i, j) = 0;
				}
		}
		merge(Conteneurs,ImgFiltrePasseHaut);

		return ImgFiltrePasseHaut;

}

