#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>

using namespace cv;
using namespace std;

Mat ResizeImg (Mat ImgEntree);
Mat TransformeFourier (Mat ImgRedimensionnee);
Mat ComputeNorme (Mat ImgTransformeFourier);
Mat CadransChange (Mat ImgNormeFourier);
Mat TransformeFourierInverse (Mat ImgTransformeFourier, int nbrelignes, int nbrecolones);
Mat FiltrePasseBas (Mat ImgTransformeFourier, float frequencecoupure );
Mat FiltrePasseHaut (Mat ImgTransformeFourier, float frequencecoupure );
