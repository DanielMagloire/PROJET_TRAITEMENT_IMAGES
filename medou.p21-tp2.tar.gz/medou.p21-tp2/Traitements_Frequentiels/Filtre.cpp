#include "Traitement.h"
#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>


int main( int argc, char** argv )
{
    int choix;
    float frec;
	if(argc!= 2 ){
		cout << "Veuillez suivre la sytaxe suivante:./Filtre mon_image "<<endl;
	}
	else
	{
		cout << "Veuillez faire le choix de l'opération"<<endl;
		cout << "Taper le chiffre 1 pour le filtre passe bas"<<endl;
		cout << "Taper le chiffre 2 pour le filtre passe haut"<<endl;
		cout << "choix :";
        cin >> choix;
        cout << "Veuillez Entrer la frequence de coupure (un nombre flottant entre 0 et 1) :";
        cin >> frec;
		const char* NomImg = argv[1];

		// Ouverture de l'image en nuance de gris
		Mat ImgEntree = imread(NomImg, CV_LOAD_IMAGE_GRAYSCALE);

		if(!ImgEntree.data){
			cout << "Veuillez à ce que vous fournissez une image valide"<<endl;
			return -1;
		}
		else{

			// Calcul de la transformée de fourier de l'image

			 Mat ImgTransformeFourier = TransformeFourier(ResizeImg(ImgEntree));

			 Mat ImgTransformeTraitee;

			 //Application du filtre suivant le choix
			 if(choix == 1){
				 ImgTransformeTraitee = FiltrePasseBas(ImgTransformeFourier, frec);
			 }
			 else if(choix == 2){
				 ImgTransformeTraitee = FiltrePasseHaut(ImgTransformeFourier, frec);
			 }

			 //Détermination de la norme du spectre
			 //Mat FramesChange;
			 Mat SpectreInitial = FramesChange(ComputeNorme(ImgTransformeFourier));
			 Mat SpectreTraite =  ComputeNorme(ImgTransformeTraitee);

			 Mat ImgTransformeInverse = TransformeFourierInverse(FramesChange(ImgTransformeTraitee),ImgEntree.rows, ImgEntree.cols);

			 //Affichage des différentes images
			 imshow("Image Entree", ImgEntree);
			 imshow("Spectre de Fourier Initial", SpectreInitial);
			 imshow("Spectre de Fourier Traite", SpectreTraite);
			 imshow("Image Apres Traitement", ImgTransformeInverse);

			 // Enregistrement de l'image originale
			 if(!imwrite("Image_Entree.png", ImgEntree))
			     cout<<"Erreur lors de l'enregistrement"<<endl;

			// Enregistrement de l'image du spectre initial
			 if(!imwrite("Spectre_initial.png", SpectreInitial))
			     cout<<"Erreur lors de l'enregistrement"<<endl;

			 // Enregistrement de l'image du spectre filtré
			 if(!imwrite("Spectre_traite.png", SpectreTraite))
			 	cout<<"Erreur lors de l'enregistrement"<<endl;

			// Enregistrement de l'image de la transformée inverse de fourier du filtrage
			 if(!imwrite("Image_Restauree.png", ImgTransformeInverse))
			     cout<<"Erreur lors de l'enregistrement"<<endl;

			 waitKey();

    		 return 0;

		}
	}
}
